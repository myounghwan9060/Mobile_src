package com.cj.mobile;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({  M_021.class,M_022.class,M_023.class,M_024.class,M_025.class,M_026.class,M_027.class,M_028.class,M_029.class,
		M_030.class ,M_031.class,M_032.class,M_033.class,M_034.class,M_035.class,M_036.class,M_037.class,M_038.class,M_039.class,
		M_040.class })

public class AllTests {

}
